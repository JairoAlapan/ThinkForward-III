import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import ScrollToTop from './components/ScrollToTop';
// Add page imports here
import SiteLayout from '@/components/layout/SiteLayout';
import Home from '@/pages/Home';
import ComputationalThinking from '@/pages/ComputationalThinking';
import InnovationReadiness from '@/pages/InnovationReadiness';
import ThinkAboutIt from '@/pages/ThinkAboutIt';
import InnovationCorner from '@/pages/InnovationCorner';
import MyIdeas from '@/pages/MyIdeas';
import Resources from '@/pages/Resources';

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  // Show loading spinner while checking app public settings or auth
  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  // Handle authentication errors
  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      // Redirect to login automatically
      navigateToLogin();
      return null;
    }
  }

  // Render the main app
  return (
    <Routes>
      <Route element={<SiteLayout />}>
        <Route path="/" element={<Home />} />
        <Route path="/computational-thinking" element={<ComputationalThinking />} />
        <Route path="/innovation-readiness" element={<InnovationReadiness />} />
        <Route path="/think-about-it" element={<ThinkAboutIt />} />
        <Route path="/innovation-corner" element={<InnovationCorner />} />
        <Route path="/my-ideas" element={<MyIdeas />} />
        <Route path="/resources" element={<Resources />} />
        <Route path="*" element={<PageNotFound />} />
      </Route>
    </Routes>
  );
};


function App() {

  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <ScrollToTop />
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App